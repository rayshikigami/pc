let messageBox = document.getElementById('messages');
messageBox.innerHTML += 'hi mother fucer';
console.debug("操你媽");